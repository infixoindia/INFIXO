#!/usr/bin/env python3
"""Local preparation only. Never pushes, deploys, migrates or reads credentials."""
import argparse, hashlib, json, os, pathlib, subprocess, tempfile
P=pathlib.Path
root=P(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
a=argparse.ArgumentParser();a.add_argument('--prepare-only',action='store_true');args=a.parse_args()
def run(*cmd,cwd=None,env=None):
 subprocess.run(cmd,cwd=cwd,env=env,check=True)
def git(*cmd):
 return subprocess.check_output(['git',*cmd],text=True).strip()
repo=P(git('rev-parse','--show-toplevel'))
origin=git('remote','get-url','origin').rstrip('/')
if origin not in ['https://github.com/infixoindia/INFIXO.git','https://github.com/infixoindia/INFIXO','git@github.com:infixoindia/INFIXO.git']:
 raise SystemExit('Stop: this is not infixoindia/INFIXO.')
# Validate every payload before changing even the new worktree.
for f,h in m['files'].items():
 p=P(f)
 if p.is_absolute() or '..' in p.parts or p.name.startswith('.env'):raise SystemExit('Unsafe payload path')
 if hashlib.sha256((root/'files'/p).read_bytes()).hexdigest()!=h:raise SystemExit('Payload checksum mismatch: '+f)
run('git','fetch','origin','main')
if git('rev-parse','origin/main')!=m['base']:raise SystemExit('Main changed. Stop for a fresh conflict review; nothing applied.')
branch=m['branch']
if subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/'+branch]).returncode==0:raise SystemExit('Branch already exists. Resume it instead of reinstalling.')
out=repo.parent/'INFIXO-acquisition-staging'
if out.exists():raise SystemExit('Staging folder already exists. Nothing overwritten.')
run('git','worktree','add','-b',branch,str(out),m['base'])
# Remove tracked env only from the newly-created isolated worktree, never the original checkout.
(out/'.env.local').unlink(missing_ok=True)
for f in m['files']:
 p=out/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/'files'/f).read_bytes())
run('git','add','--','.env.local',*m['files'],cwd=out)
if not args.prepare_only:
 env=dict(os.environ)
 for k in list(env):
  if k.startswith(('NEXT_PUBLIC_SUPABASE','SUPABASE_','INFIXO_','VERCEL_')):env.pop(k)
 env.update(NEXT_PUBLIC_SUPABASE_URL='https://synthetic.invalid',NEXT_PUBLIC_SUPABASE_ANON_KEY='synthetic-only')
 run('npm','ci','--ignore-scripts',cwd=out,env=env)
 with tempfile.TemporaryDirectory(prefix='infixo-test-tools-') as t:
  P(t,'package.json').write_text('{"private":true}')
  run('npm','install','--ignore-scripts','--no-audit','--no-fund','esbuild@0.25.12','@electric-sql/pglite@0.3.14','react@19.2.8','react-test-renderer@19.2.8',cwd=t,env=env)
  env['ACQUISITION_TEST_DEPS']=t
  for f in ['acquisition.test.mjs','acquisition-db.mjs','acquisition-api.mjs','acquisition-ui.mjs']:run('node','tests/'+f,cwd=out,env=env)
 run('npm','run','build',cwd=out,env=env)
run('git','commit','-m','Prepare approved INFIXO acquisition staging integration',cwd=out)
print('Prepared:',out,'Branch:',branch)
print('NO push, deployment or database migration performed. Resolve Vercel scope and preview isolation before pushing.')
