# INFIXO approved staging integration kit

Latest approved UI, transparent complete logo, demo language rules, API/admin/migration included.

Installer creates a separate local worktree from reviewed GitHub main. Your existing checkout and uncommitted work remain intact. It refuses changed main, existing branch, existing target folder or altered payload. No GitHub push, Vercel deploy, production calls or migration execution. No secrets or environment files are included. Existing tracked .env.local is removed only from the new worktree; Git history still needs a separately approved security response.

Unzip outside the repository. From the existing INFIXO Codespaces terminal run `python3 /absolute/path/INSTALL.py`. Default runs npm ci, pinned test-tool installation, isolated unit/DB/API/UI checks and production build with synthetic environment. Internet access is required for npm. Stops on failure; never discards work. `--prepare-only` skips tests/build and is used only to validate installation mechanics.

Current blockers: GitHub connector write 403; Vercel sigmaoo7 scope 403; Supabase SIGMA has only production/main. Do not push until Vercel auto-deployment, secrets and private staging database are reviewed. Branch-specific Vercel deployment guard is included but not a substitute for reviewing project settings.

Tests already executed by agent: actual migration in isolated PGlite, API handlers with mocked transport, UI components. These are not live Supabase/Vercel end-to-end tests. Latest staging Next.js build passed after correcting a local node_modules symlink. Actual Android browser testing remains pending.
