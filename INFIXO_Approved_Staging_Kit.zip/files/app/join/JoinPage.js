'use client';
import CompleteLogo from './CompleteLogo';
import {useEffect,useRef,useState} from 'react';
import TargetProgress from './TargetProgress';
import {CAMPAIGN,CATEGORIES,WORK_MODELS,REASONS,countdown,offerActive,attributionFrom,validateLead} from '@/lib/acquisition/config.mjs';
import {referencePrice} from '@/lib/acquisition/hindi.mjs';
import {fill} from '@/lib/acquisition/i18n.mjs';
import {useJoinLanguage,LanguageSwitcher} from '@/lib/acquisition/locale';
import {getJoinSession,sendLead} from '@/lib/acquisition/client.mjs';
import s from './join.module.css';
const blank={name:'',phone:'',profession:'',area:'',working_model:'',reason:'',question:'',consent:false,website:''};
export default function JoinPage({serverNow,preview=false}){
 const {language,changeLanguage,t}=useJoinLanguage();
 const [now,setNow]=useState(serverNow),[offset,setOffset]=useState(0),[plan,setPlan]=useState(''),[fields,setFields]=useState(blank);
 const [token,setToken]=useState(''),[attribution,setAttribution]=useState({}),[busy,setBusy]=useState(false),[success,setSuccess]=useState(false),[previewResult,setPreviewResult]=useState(false),[error,setError]=useState(''),[slide,setSlide]=useState(0),[formVisible,setFormVisible]=useState(false),[draftReady,setDraftReady]=useState(false);
 const lock=useRef(false),formRef=useRef(null),carousel=useRef(null),errorRef=useRef(null);
 const active=offerActive(now),demoHref=`/demo/worker?lang=${language}`,privacyHref=`/join/privacy?lang=${language}`;
 const refreshToken=async()=>{try{const d=await getJoinSession();setToken(d.token);setOffset(d.serverNow-Date.now());setNow(d.serverNow);}catch{setError('session');}};
 useEffect(()=>{setOffset(serverNow-Date.now());refreshToken();let current=attributionFrom(new URLSearchParams(window.location.search));try{const saved=JSON.parse(sessionStorage.getItem('infixo-join-attribution')||'{}');current=Object.keys(current).length?current:attributionFrom(new URLSearchParams(saved));sessionStorage.setItem('infixo-join-attribution',JSON.stringify(current));}catch{}setAttribution(current);},[]);
 useEffect(()=>{const timer=setInterval(()=>setNow(Date.now()+offset),1000);return()=>clearInterval(timer);},[offset]);
 useEffect(()=>{if(!active&&plan==='PRO'){setPlan('');setError('expired');}},[active,plan]);
 useEffect(()=>{if(typeof IntersectionObserver==='undefined')return;const observer=new IntersectionObserver(([entry])=>setFormVisible(entry.isIntersecting),{threshold:0});observer.observe(formRef.current);return()=>observer.disconnect();},[]);
 useEffect(()=>{try{const d=JSON.parse(sessionStorage.getItem('infixo-join-draft')||'null');if(d){setFields({...blank,...Object.fromEntries(Object.keys(blank).filter(k=>k!=='website'&&typeof d.fields?.[k]===typeof blank[k]).map(k=>[k,d.fields[k]]))});if(['FREE','PRO'].includes(d.plan))setPlan(d.plan);}}catch{}setDraftReady(true);},[]);
 useEffect(()=>{if(!draftReady||success)return;try{sessionStorage.setItem('infixo-join-draft',JSON.stringify({fields,plan}));}catch{}},[fields,plan,draftReady,success]);
 function setField(e){const {name,value,type,checked}=e.target;setFields(f=>({...f,[name]:type==='checkbox'?checked:value}));}
 function goSlide(index){carousel.current?.children[index]?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'nearest',inline:'start'});}
 function showError(code){setError(code in t.errors?code:'invalid');setTimeout(()=>errorRef.current?.focus(),0);}
 async function submit(e){e.preventDefault();if(lock.current||success||!fields.consent)return;const payload={...fields,question:fields.reason===REASONS[0]?'':fields.question,plan,token,attribution,preferred_language:language};
  try{validateLead(payload,now);}catch(e){showError(e.code);return;}
  lock.current=true;setBusy(true);setError('');try{const result=await sendLead(payload);setPreviewResult(result.preview===true);setSuccess(true);try{sessionStorage.removeItem('infixo-join-draft');}catch{}setTimeout(()=>document.getElementById('join-success')?.focus(),0);}catch(e){showError(e.message);await refreshToken();}finally{lock.current=false;setBusy(false);}
 }
 const fieldError=name=>error===name?`${name}-error`:undefined;
 return <main className={s.page} lang={language==='hi'?'hi':'en'}>
  <header className={s.header}><a href="/join" aria-label="INFIXO"><CompleteLogo/></a><span className={s.city}><i/>{t.city}</span><LanguageSwitcher language={language} onChange={changeLanguage} className={s.language}/></header>
  {preview&&<aside className={s.privateNote}>{t.privateNote}</aside>}
  <section className={s.hero}><div className={s.heroCopy}><span className={s.eyebrow}>{t.eyebrow}</span><h1>{t.headline}</h1><p>{t.intro}</p><div className={s.actions}><a className={s.primary} href="#apply">{t.join}<span>↗</span></a><a className={s.secondary} href={demoHref}>{t.demoButton}<span>▷</span></a></div></div>
  </section>
  <section className={s.offer} aria-labelledby="offer-title"><div><h2 id="offer-title">{active?t.offer:t.expired}</h2><p>{active?t.offerEnd:t.expiredInfo}</p></div>{active&&<div className={s.countdown} aria-label={t.countdown}>{countdown(now).map((v,i)=><div key={i}><strong suppressHydrationWarning>{String(v).padStart(2,'0')}</strong><span>{t.time[i]}</span></div>)}</div>}</section>
  <section id="plans" className={s.section} aria-labelledby="plans-title"><div className={s.sectionHead}><div><h2 id="plans-title">{t.plansTitle}</h2></div></div>
   <div ref={carousel} className={s.plans} aria-label={t.planNav} onScroll={e=>{const el=e.currentTarget;setSlide(el.scrollLeft>(el.children[1]?.offsetLeft-el.children[0]?.offsetLeft)/2?1:0);}}>{['FREE','PRO'].map((p,index)=>{const ref=active?referencePrice(p,preview,CAMPAIGN):null;return <article key={p} className={`${s.plan} ${index?s.pro:''}`} aria-label={`${p} ${t.profile}`}><div className={s.planTop}><h3>{p} <span>{t.profile}</span></h3>{active&&<span className={s.offerPill}>{t.offerTag}</span>}</div><div className={s.price}>{ref&&<del aria-label={`${t.referenceA11y} ₹${ref.amount}`}>₹{ref.amount}</del>}{index&&!active?<strong className={s.expiredPrice}>{t.newPrice}</strong>:<><strong>₹{index?'199':'0'}</strong><span>{index?t.oneTime:'FREE'}</span></>}</div><ul className={s.featureList}>{(index?t.featuresPro:t.featuresFree).map((text,i)=><li key={i} className={i===6?s.editFeature:''}><span aria-hidden="true">✓</span>{text}</li>)}</ul></article>;})}</div>
   <div className={s.dots} aria-label={t.planNav}>{['FREE','PRO'].map((p,i)=><button key={p} type="button" aria-label={fill(t.viewPlan,{plan:p})} aria-pressed={slide===i} className={slide===i?s.activeDot:''} onClick={()=>goSlide(i)}><span/></button>)}</div>
  </section>
  <section id="apply" ref={formRef} className={`${s.section} ${s.apply}`}><div className={s.formIntro}><span className={s.eyebrow}>{t.formEyebrow}</span><h2>{t.formTitle}</h2><ol className={s.steps}>{t.steps.map((v,i)=><li key={i}><span aria-hidden="true"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{i===0?<><path d="m4 12 16-8-8 16-1-7-7-1Z"/><path d="m11 13 9-9"/></>:i===1?<><path d="M5 4h4l2 5-3 2a14 14 0 0 0 5 5l2-3 5 2v4c-9 3-18-6-15-15Z"/></>:<path d="m5 12 4 4L19 6"/>}</svg></span><div><strong>{v}</strong></div></li>)}</ol></div>
   <div className={s.formCard}>{success?<div id="join-success" tabIndex={-1} className={s.success}><h3>{previewResult?t.testSuccess:t.success}</h3><p>{previewResult?t.testBody:t.successBody}</p><button className={s.primary} onClick={()=>{setSuccess(false);setError('');}}>{t.back}</button></div>:<form onSubmit={submit} noValidate aria-label={t.formA11y}>
    <fieldset className={s.formPlans}><legend>{t.choosePlan}</legend><div className={s.radioGrid}>{['FREE','PRO'].map((p,i)=><label key={p} className={`${s.radioCard} ${plan===p?s.radioSelected:''}`}><input name="plan" type="radio" value={p} checked={plan===p} disabled={p==='PRO'&&!active} onChange={()=>{setPlan(p);setError('');}}/><span><strong>{i===2?t.undecided:p}</strong>{i<2&&<small>{i===1&&!active?t.newPrice:`₹${i?'199':'0'}${i?' · '+t.oneTime:''}`}</small>}</span></label>)}</div></fieldset>
    <div className={s.formGrid}><label>{t.name}<input name="name" value={fields.name} onChange={setField} autoComplete="name" minLength={2} maxLength={100} placeholder={t.namePlaceholder} required aria-invalid={error==='name'} aria-describedby={fieldError('name')}/></label><label>{t.phone}<input name="phone" value={fields.phone} onChange={setField} type="tel" inputMode="tel" autoComplete="tel" maxLength={17} placeholder={t.phonePlaceholder} required aria-invalid={error==='phone'} aria-describedby={fieldError('phone')}/></label><label>{t.profession}<select name="profession" value={fields.profession} onChange={setField} required><option value="" disabled>{t.professionPlaceholder}</option>{CATEGORIES.map((c,i)=><option key={c.name} value={c.name}>{t.professions[i]}</option>)}</select></label><label>{t.area}<input name="area" value={fields.area} onChange={setField} autoComplete="address-level3" minLength={2} maxLength={120} placeholder={t.areaPlaceholder} required/></label></div>
    <label>{t.model}<select name="working_model" value={fields.working_model} onChange={setField} required><option value="" disabled>{t.select}</option>{WORK_MODELS.map((v,i)=><option key={v} value={v}>{t.models[i]}</option>)}</select></label>
    <label>{t.reason}<select name="reason" value={fields.reason} onChange={setField} required><option value="" disabled>{t.select}</option>{REASONS.map((v,i)=><option key={v} value={v}>{t.reasons[i]}</option>)}</select></label>
    {fields.reason&&fields.reason!==REASONS[0]&&<label>{t.question}<textarea name="question" value={fields.question} onChange={setField} maxLength={1000} rows={3} placeholder={t.questionPlaceholder}/></label>}
    <div className={s.honeypot} aria-hidden="true"><label>{t.website}<input name="website" value={fields.website} onChange={setField} tabIndex={-1} autoComplete="off"/></label></div>
    <label className={s.consent}><input type="checkbox" name="consent" checked={fields.consent} onChange={setField} required/><span>{t.consent} <a href={privacyHref} target="_blank" rel="noopener">{t.privacy}</a></span></label>
    {error&&!(error==='consent'&&!fields.consent)&&<p ref={errorRef} id={`${error}-error`} role="alert" tabIndex={-1} className={s.error}>{t.errors[error]||t.errors.invalid}</p>}<button className={s.primary} type="submit" disabled={busy||!token||!fields.consent}>{busy?t.sending:t.submit}<span>→</span></button>{!token&&<button className={s.retry} type="button" onClick={refreshToken}>{t.retry}</button>}
   </form>}</div></section>
  <section className={s.section} aria-labelledby="targets-title"><div className={s.sectionHead}><div><h2 id="targets-title" className={s.targetHeading}>This Diwali Month Target</h2><p>{t.targetNote}</p></div><span aria-hidden="true">🪔</span></div><TargetProgress language={language}/></section>
  <section className={`${s.section} ${s.faq}`}><h2>{t.faqTitle}</h2>{t.faqs.map(([q,a],i)=><details key={i}><summary>{q}<span>+</span></summary><p style={i===1?{whiteSpace:'pre-line'}:undefined}>{a}</p></details>)}</section>
  <footer className={s.footer}><CompleteLogo className={s.footerLogo}/><div><a href={privacyHref}>{t.privacy}</a><a href={`/join/terms?lang=${language}`}>{t.terms}</a></div><span>{t.location}</span></footer>
  {!success&&!formVisible&&<div className={s.sticky}><a className={s.primary} href="#apply">{t.join}<span>↗</span></a></div>}
 </main>;
}
