#!/usr/bin/env python3
"""Apply INFIXO Admin Work Photos correction to a clean review branch only."""
import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

BASE_BLOBS = {
    'app/components/admin/WorkPhotosEditor.js': '54ef1716b7ecaff81aef67b6cbcbeb4c83dc9461',
    'app/components/admin/PhotoCropper.js': '36322059442f7dea0317468de0de6db3fabedef2',
    'app/components/WorkPhotos/WorkPhotos.js': '0e477725931c69ed0ac845ed358104f305a0a071',
    'app/components/admin/AdminWorkerEditor.js': 'f5ff614aba5e38bfcaf805860e3af5b703d7c79e',
    'lib/storageService.js': 'bcc9dac5980f193b240f64223a43b28745048f3c',
    'vercel.json': '450d7d1ae76de56523e6f80e12091035efa8f3dc',
}
COPY_REPLACEMENTS = [
    'app/components/admin/WorkPhotosEditor.js',
    'app/components/admin/WorkPhotosEditor.module.css',
    'app/components/admin/PhotoCropper.js',
    'lib/storageService.js',
    'lib/workPhoto.mjs',
    'tests/work-photo.test.mjs',
    'docs/PHOTO_UPLOAD_CORRECTIONS.md',
]


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def blob_sha(data):
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


def replace_once(text, old, new, path):
    seen = text.count(old)
    if seen != 1:
        raise RuntimeError(f'{path}: expected 1 occurrence of a patch anchor, found {seen}: {old[:100]}')
    return text.replace(old, new, 1)


def patch_work_photos(text):
    p = 'app/components/WorkPhotos/WorkPhotos.js'
    text = replace_once(text,
        'import styles from "./WorkPhotos.module.css";',
        'import styles from "./WorkPhotos.module.css";\nimport CroppedImage from "../CroppedImage/CroppedImage";\nimport { workPhotoDisplay } from "@/lib/workPhoto.mjs";', p)
    text = replace_once(text,
        '  const images = worker?.photos || [];',
        '  // Supports old URL strings and new { image: originalUrl, crop } entries.\n'
        '  const images = (worker?.photos || []).map(workPhotoDisplay).filter(image => image.src);', p)
    text = replace_once(text,
        '            <img src={image} alt={`Work ${index + 1}`} />',
        '            {image.crop\n'
        '              ? <CroppedImage src={image.src} crop={image.crop} alt={`Work ${index + 1}`} />\n'
        '              : <img src={image.src} alt={`Work ${index + 1}`} />}', p)
    text = replace_once(text,
        '                      src={image}',
        '                      src={image.src}', p)
    return text


def patch_admin_editor(text):
    p = 'app/components/admin/AdminWorkerEditor.js'
    text = replace_once(text,
        '  const [showPreview, setShowPreview] = useState(true);',
        '  const [showPreview, setShowPreview] = useState(true);\n  const [photoDraftDirty, setPhotoDraftDirty] = useState(false);\n  const [photoPreview, setPhotoPreview] = useState(null);', p)
    text = replace_once(text,
        '                onClick={() => setActiveTab(tab.key)}',
        '                onClick={() => {\n                  if (activeTab === \"photos\" && tab.key !== \"photos\" && photoDraftDirty &&\n                      !window.confirm(\"Unsaved Work Photos changes will be discarded. Continue?\")) return;\n                  setActiveTab(tab.key);\n                }}', p)
    text = replace_once(text,
        '            <WorkPhotosEditor\n              worker={worker}',
        '            <WorkPhotosEditor\n              worker={worker}\n              onDirtyChange={setPhotoDraftDirty}\n              onPreviewChange={setPhotoPreview}', p)
    text = replace_once(text,
        '                  {activeTab === "photos" && <WorkPhotos worker={worker} backHref="#" />}',
        '                  {activeTab === "photos" && <WorkPhotos worker={{ ...worker, photos: photoPreview ?? worker.photos }} backHref="#" />}', p)
    return replace_once(text,
        '  const savePhotos = () => saveSection("photos", ["photos"]);',
        '''  // Photo editor stages and uploads originals first. Commit the entire
  // array in ONE DB write; preserve the previous record if that write fails.
  const savePhotos = async (nextPhotos) => {
    setSavingSection("photos");
    try {
      const updated = await updateWorker(worker.id, { photos: nextPhotos });
      setWorker(updated);
      flashMessage("photos", "Saved!");
      return updated.photos;
    } catch (err) {
      flashMessage("photos", err?.message || "Save failed. Try again.", true);
      throw err;
    } finally {
      setSavingSection(null);
    }
  };''', p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', required=True, type=Path)
    args = ap.parse_args()
    repo = args.repo.resolve()
    package_dir = Path(__file__).resolve().parent
    if not (repo / '.git').exists():
        raise RuntimeError('Not a Git repository root. Run from the INFIXO repository.')
    branch = git(repo, 'branch', '--show-current')
    if branch != 'feat/admin-photo-corrections':
        raise RuntimeError(f'Refusing branch {branch!r}. Create/use feat/admin-photo-corrections from current main.')
    dirty = git(repo, 'status', '--porcelain').splitlines()
    allowed = { '?? INFIXO_Admin_Photo_Corrections.zip' }
    if [line for line in dirty if line not in allowed]:
        raise RuntimeError('Git worktree is not clean. Commit/stash unrelated changes first.')

    # Check EVERY target before writing anything; never overwrite a changed source.
    for path, expected in BASE_BLOBS.items():
        file = repo / path
        if not file.exists() or blob_sha(file.read_bytes()) != expected:
            raise RuntimeError(f'Baseline mismatch: {path}. No files changed. Ask for a patch update.')
    for path in COPY_REPLACEMENTS:
        if path not in BASE_BLOBS and (repo / path).exists():
            raise RuntimeError(f'New patch target already exists: {path}. No files changed.')

    updated = {}
    for path in COPY_REPLACEMENTS:
        updated[path] = (package_dir / path).read_bytes()
    for path, callback in [
        ('app/components/WorkPhotos/WorkPhotos.js', patch_work_photos),
        ('app/components/admin/AdminWorkerEditor.js', patch_admin_editor),
    ]:
        source = (repo / path).read_text('utf-8')
        updated[path] = callback(source).encode('utf-8')
    config = json.loads((repo / 'vercel.json').read_text('utf-8'))
    config['git']['deploymentEnabled']['feat/admin-photo-corrections'] = False
    updated['vercel.json'] = (json.dumps(config, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    for path, content in updated.items():
        dest = repo / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(content)
    print('Applied Admin Work Photos patch to review branch:', branch)
    for path in updated: print('  ', path)
    print('PRODUCTION UNCHANGED. NEXT: npm ci; node --test tests/work-photo.test.mjs; npm run build')
    print('DO NOT MERGE until isolated staging visual/API QA passes.')


if __name__ == '__main__':
    main()
