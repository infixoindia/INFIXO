INFIXO — ADMIN WORK PHOTOS CORRECTIONS (2026-10-16)

THIS ZIP IS A CANDIDATE PATCH. NOTHING IS DEPLOYED BY DOWNLOADING OR UNZIPPING IT.

Scoped ONLY to Admin Work Photos. DOES NOT integrate Cloudflare R2 or change Videos, Landing Page, Admin Leads, Map, public layout, production secrets or DB.

HOW TO APPLY IN GITHUB CODESPACES (after user review):
1) Open the repository infixoindia/INFIXO in Codespaces.
2) Make sure your current work is committed, then:

   git status --short
   git switch main
   git pull --ff-only origin main
   git switch -c feat/admin-photo-corrections

3) Upload INFIXO_Admin_Photo_Corrections.zip into the repository's ROOT (or access it from Downloads).
4) Run from the repository root (if uploaded to repo root):

   unzip -o INFIXO_Admin_Photo_Corrections.zip -d /tmp/infixo-admin-photo
   python /tmp/infixo-admin-photo/INFIXO_Admin_Photo_Corrections/APPLY.py --repo "$PWD"
   git diff --stat
   git diff -- app/components/WorkPhotos/WorkPhotos.js app/components/admin/AdminWorkerEditor.js vercel.json
   npm ci
   node --test tests/work-photo.test.mjs
   npm run build
   git status --short

IMPORTANT: The installer refuses changed original files, wrong branches, or dirty worktrees.
Do not deploy/merge to main until isolated STAGING browser QA. On this branch,
automatic Vercel preview deployment is deliberately disabled to prevent
an unverified preview from accidentally touching SIGMA.

5) If local checks pass, stage ONLY relevant paths (do not add ZIP or .env):

   git add app/components/admin/WorkPhotosEditor.js \
     app/components/admin/WorkPhotosEditor.module.css \
     app/components/admin/PhotoCropper.js \
     app/components/admin/AdminWorkerEditor.js \
     app/components/WorkPhotos/WorkPhotos.js \
     lib/storageService.js lib/workPhoto.mjs \
     tests/work-photo.test.mjs docs/PHOTO_UPLOAD_CORRECTIONS.md vercel.json
   git commit -m "Improve admin work photo upload and non-destructive crop"

Do NOT push to production/main or activate a paid service. Ask for staging
preview configuration and go-live authorization separately.

If an error says BASELINE MISMATCH, STOP; do not force-copy the patch over newer code.

See docs/PHOTO_UPLOAD_CORRECTIONS.md for the exact behavior and QA checklist.
