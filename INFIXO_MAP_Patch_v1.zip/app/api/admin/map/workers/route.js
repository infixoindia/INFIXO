import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
const DEFAULT_SUPABASE_URL = "https://xyplrbzyqershqngrjwo.supabase.co";
function getSupabaseUrl() { const raw=String(process.env.NEXT_PUBLIC_SUPABASE_URL||"").trim().replace(/^[\"']|[\"']$/g,""); try { const u=new URL(raw); if (u.protocol==='http:'||u.protocol==='https:') return u.toString().replace(/\/$/,""); } catch {} return DEFAULT_SUPABASE_URL; }
function isAdmin(request) { const expected=process.env.INFIXO_ADMIN_SECRET; return !!expected && request.cookies.get("infixo_admin")?.value===expected; }
function client() { const key=process.env.SUPABASE_SERVICE_ROLE_KEY; if(!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY is not configured"); return createClient(getSupabaseUrl(),key,{auth:{autoRefreshToken:false,persistSession:false}}); }
const norm=v=>String(v||"").trim().toLowerCase();
export async function GET(request) {
  if(!isAdmin(request)) return NextResponse.json({error:"Unauthorized"},{status:401});
  try {
    const q=norm(new URL(request.url).searchParams.get("q"));
    const {data,error}=await client().from("workers").select("id,worker_id,slug,ipuc,full_name,profession,primary_skill,is_active,worker_service_areas(latitude,longitude,radius_km,city,locality)").order("created_at",{ascending:false});
    if(error) throw error;
    const workers=(data||[]).map(w=>{const areas=Array.isArray(w.worker_service_areas)?w.worker_service_areas:[]; const a=areas.find(x=>Number.isFinite(Number(x.latitude))&&Number.isFinite(Number(x.longitude)))||null; return {id:w.id,workerId:w.worker_id||"",slug:w.slug||"",ipuc:w.ipuc||"",fullName:w.full_name||"",profession:w.profession||w.primary_skill||"",isActive:w.is_active!==false,latitude:a?Number(a.latitude):null,longitude:a?Number(a.longitude):null,radiusKm:a?.radius_km==null?null:Number(a.radius_km),locality:a?.locality||"",city:a?.city||""};}).filter(w=>!q||[w.workerId,w.fullName,w.profession,w.ipuc,w.slug].some(v=>norm(v).includes(q)));
    return NextResponse.json({workers,totalWorkers:data?.length||0});
  } catch(e) { return NextResponse.json({error:e.message||"Failed to load map workers"},{status:500}); }
}
