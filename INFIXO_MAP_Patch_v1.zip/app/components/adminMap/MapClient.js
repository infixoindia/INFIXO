"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import styles from "./MapClient.module.css";
import { buildWorkerHexes, featureCentroid, parentKeyForLonLat, polygonCoordinates } from "./hexGrid";

const CATEGORY_NAMES = ["Painter", "Plumber", "Electrician"];

function projectFactory(features) {
  const points = [];
  for (const f of features || []) points.push(...polygonCoordinates(f.geometry));
  const minLon = Math.min(...points.map(p => Number(p[0]))), maxLon = Math.max(...points.map(p => Number(p[0])));
  const minLat = Math.min(...points.map(p => Number(p[1]))), maxLat = Math.max(...points.map(p => Number(p[1])));
  const padX = Math.max((maxLon-minLon)*0.03, 0.001), padY = Math.max((maxLat-minLat)*0.03, 0.001);
  const lo=minLon-padX, hi=maxLon+padX, la=minLat-padY, ha=maxLat+padY;
  return {viewBox:`0 0 1000 760`, project([lon,lat]){return [((lon-lo)/(hi-lo))*1000,760-((lat-la)/(ha-la))*760]}};
}
function pathFromRing(ring, project){return ring.map((p,i)=>{const [x,y]=project(p);return `${i?'L':'M'} ${x.toFixed(2)} ${y.toFixed(2)}`}).join(' ')+' Z'}
function featurePath(feature,project){const g=feature.geometry;if(!g)return'';if(g.type==='Polygon')return pathFromRing(g.coordinates?.[0]||[],project);if(g.type==='MultiPolygon')return(g.coordinates||[]).map(p=>pathFromRing(p?.[0]||[],project)).join(' ');return''}
function labelForHex(f){return f?.properties?.hex_id||f?.properties?.hexId||"Customer Hex"}
function wardForHex(f){const p=f?.properties||{};return p.primary_ward_name||p.primary_ward||p.ward_name||p.ward||"—"}

export default function MapClient(){
  const [customer,setCustomer]=useState([]); const [boundary,setBoundary]=useState(null); const [workers,setWorkers]=useState([]);
  const [customerOn,setCustomerOn]=useState(true); const [workerOn,setWorkerOn]=useState(true); const [selected,setSelected]=useState(null);
  const [search,setSearch]=useState(""); const [searching,setSearching]=useState(false); const [error,setError]=useState("");
  useEffect(()=>{Promise.all([fetch('/gis/infixo_hex_grid_indore.geojson').then(r=>r.ok?r.json():Promise.reject(new Error('Customer Hex GeoJSON not found'))),fetch('/gis/imc_boundary_dissolved.geojson').then(r=>r.ok?r.json():null)]).then(([h,b])=>{setCustomer(h.features||[]);setBoundary(b)}).catch(e=>setError(`${e.message}. Put the four existing GIS files in public/gis/.`));},[]);
  const loadWorkers=async(q="")=>{setSearching(true);try{const r=await fetch(`/api/admin/map/workers${q?`?q=${encodeURIComponent(q)}`:''}`,{cache:'no-store'});const b=await r.json();if(!r.ok)throw new Error(b.error||'Could not load workers');setWorkers(b.workers||[])}catch(e){setError(e.message)}finally{setSearching(false)}};
  useEffect(()=>{loadWorkers()},[]);
  const projection=useMemo(()=>customer.length?projectFactory(customer):null,[customer]);
  const workerHexes=useMemo(()=>buildWorkerHexes(customer),[customer]);
  const workersByHex=useMemo(()=>{const m=new Map();for(const w of workers){if(w.latitude==null||w.longitude==null)continue;const k=parentKeyForLonLat(w.longitude,w.latitude);if(!m.has(k))m.set(k,[]);m.get(k).push(w)}return m},[workers]);
  const categoryCounts=useMemo(()=>{const c={Painter:0,Plumber:0,Electrician:0};for(const w of workers){const p=(w.profession||'').toLowerCase();for(const n of CATEGORY_NAMES)if(p.includes(n.toLowerCase()))c[n]++}return c},[workers]);
  const activeWorkers=workers.filter(w=>w.isActive).length; const locatedWorkers=workers.filter(w=>w.latitude!=null&&w.longitude!=null).length;
  const selectedWorkerHex=selected?.type==='worker'?workerHexes.find(h=>h.workerHexId===selected.id):null;
  const selectedCustomer=selected?.type==='customer'?customer.find(f=>labelForHex(f)===selected.id):null;
  return <main className={styles.page}>
    <header className={styles.header}><div><h1>INFIXO MAP</h1><p>Customer demand layer + Worker supply planning layer</p></div><Link href="/admin/workers" className={styles.back}>Workers</Link></header>
    <section className={styles.stats}>
      <Stat label="Total Workers" value={workers.length}/><Stat label="Active" value={activeWorkers}/><Stat label="Located" value={locatedWorkers}/><Stat label="Painters" value={categoryCounts.Painter}/><Stat label="Plumbers" value={categoryCounts.Plumber}/><Stat label="Electricians" value={categoryCounts.Electrician}/>
    </section>
    <section className={styles.controls}><label><input type="checkbox" checked={customerOn} onChange={e=>setCustomerOn(e.target.checked)}/> Customer Hex</label><label><input type="checkbox" checked={workerOn} onChange={e=>setWorkerOn(e.target.checked)}/> Worker Hex</label><form onSubmit={e=>{e.preventDefault();loadWorkers(search)}}><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search Worker ID, name, profession"/><button disabled={searching}>{searching?'Searching…':'Search'}</button></form></section>
    {error&&<div className={styles.error}>{error}</div>}
    <section className={styles.mapCard}>
      {!projection?<div className={styles.empty}>Loading Customer Hex map…</div>:<svg className={styles.map} viewBox={projection.viewBox} role="img" aria-label="INFIXO Indore map">
        {boundary?.features?.map((f,i)=><path key={`b-${i}`} d={featurePath(f,projection.project)} className={styles.boundary}/>) }
        {workerOn&&workerHexes.map(h=>{const d=featurePath(h,projection.project);const count=workersByHex.get(h.workerHexId)?.length||0;const selectedNow=selectedWorkerHex?.workerHexId===h.workerHexId;return <g key={h.workerHexId} onClick={()=>setSelected({type:'worker',id:h.workerHexId})} className={selectedNow?styles.workerSelected:styles.worker}><path d={d}/>{projection.project(h.center)&&<text x={projection.project(h.center)[0]} y={projection.project(h.center)[1]}>{count}</text>}</g>})}
        {customerOn&&customer.map((f,i)=>{const id=labelForHex(f);const selectedNow=selectedCustomer&&id===labelForHex(selectedCustomer);return <path key={`c-${id}-${i}`} d={featurePath(f,projection.project)} onClick={()=>setSelected({type:'customer',id})} className={selectedNow?styles.customerSelected:styles.customer}/>})}
        {workerOn&&workers.filter(w=>w.latitude!=null&&w.longitude!=null).map(w=>{const [x,y]=projection.project([w.longitude,w.latitude]);return <circle key={w.id} cx={x} cy={y} r="5" className={styles.workerDot} onClick={()=>setSelected({type:'worker',id:parentKeyForLonLat(w.longitude,w.latitude)})}/>})}
      </svg>}
    </section>
    <section className={styles.detail}>
      {!selected&&<p className={styles.hint}>Map ready. Tap a Customer Hex or Worker Hex to inspect it.</p>}
      {selectedCustomer&&<CustomerPanel feature={selectedCustomer} workerHexes={workerHexes}/>} 
      {selectedWorkerHex&&<WorkerPanel hex={selectedWorkerHex} workers={workersByHex.get(selectedWorkerHex.workerHexId)||[]} />}
    </section>
  </main>
}
function Stat({label,value}){return <div className={styles.stat}><span>{label}</span><strong>{value}</strong></div>}
function CustomerPanel({feature,workerHexes}){const id=labelForHex(feature);const h=workerHexes.find(x=>x.customerHexIds.includes(id));return <div><div className={styles.panelTitle}>{id}</div><p>Primary Ward: <b>{wardForHex(feature)}</b></p><p>Worker Hex: <b>{h?.workerHexId||'—'}</b></p><div className={styles.grid3}><div>Queries<strong>0</strong></div><div>Painter Demand<strong>0</strong></div><div>Plumber Demand<strong>0</strong></div><div>Electrician Demand<strong>0</strong></div></div><p className={styles.note}>Demand counters will become live when customer-query data is onboarded. No fake demand is inserted.</p></div>}
function WorkerPanel({hex,workers}){return <div><div className={styles.panelTitle}>{hex.workerHexId}</div><p>Customer Hexes: <b>{hex.customerHexIds.length}</b> · Workers: <b>{workers.length}</b></p><div className={styles.grid3}><div>Painter<strong>{workers.filter(w=>(w.profession||'').toLowerCase().includes('painter')).length}</strong></div><div>Plumber<strong>{workers.filter(w=>(w.profession||'').toLowerCase().includes('plumber')).length}</strong></div><div>Electrician<strong>{workers.filter(w=>(w.profession||'').toLowerCase().includes('electrician')).length}</strong></div></div><div className={styles.workerList}>{workers.length?workers.map(w=><div key={w.id} className={styles.workerRow}><div><b>{w.workerId||'No Worker ID'}</b><span>{w.fullName||'Untitled'} · {w.profession||'—'}</span></div>{w.slug&&w.ipuc?<Link href={`/w/${w.slug}/${w.ipuc}`} target="_blank">View Profile</Link>:<span className={styles.muted}>No public link</span>}</div>):<p className={styles.hint}>No located workers in this Worker Hex yet.</p>}</div></div>}
