export const WORKER_HEX_CONFIG=Object.freeze({originLon:75.868,originLat:22.710,childFlatToFlatKm:1.5,parentAreaMultiple:7});
const R=6371.0088,D=Math.PI/180;
export function lonLatToKm([lon,lat]){const l=WORKER_HEX_CONFIG.originLat*D;return [(lon-WORKER_HEX_CONFIG.originLon)*D*R*Math.cos(l),(lat-WORKER_HEX_CONFIG.originLat)*D*R]}
export function kmToLonLat([x,y]){const l=WORKER_HEX_CONFIG.originLat*D;return [WORKER_HEX_CONFIG.originLon+(x/(R*Math.cos(l)))/D,WORKER_HEX_CONFIG.originLat+(y/R)/D]}
export function polygonCoordinates(g){if(!g)return[];if(g.type==='Polygon')return g.coordinates?.[0]||[];if(g.type==='MultiPolygon')return(g.coordinates||[]).reduce((a,p)=>(p?.[0]?.length||0)>a.length?p[0]:a,[]);return[]}
export function featureCentroid(f){const r=polygonCoordinates(f?.geometry);if(!r.length)return null;let x=0,y=0;for(const p of r){x+=Number(p[0]);y+=Number(p[1])}return[x/r.length,y/r.length]}
export function parentHexSizeKm(){return WORKER_HEX_CONFIG.childFlatToFlatKm/Math.sqrt(3)*Math.sqrt(WORKER_HEX_CONFIG.parentAreaMultiple)}
function cubeRound(q,r){let x=q,z=r,y=-x-z,rx=Math.round(x),ry=Math.round(y),rz=Math.round(z);const dx=Math.abs(rx-x),dy=Math.abs(ry-y),dz=Math.abs(rz-z);if(dx>dy&&dx>dz)rx=-ry-rz;else if(dy>dz)ry=-rx-rz;else rz=-rx-ry;return[rx,rz]}
export function parentKeyForLonLat(lon,lat){const[x,y]=lonLatToKm([lon,lat]),s=parentHexSizeKm(),q=(Math.sqrt(3)/3*x-y/3)/s,r=(2/3*y)/s,[a,b]=cubeRound(q,r);return`WH-${String(a).padStart(3,'0')}-${String(b).padStart(3,'0')}`}
export function parentCenterForKey(key){const m=/^WH-(-?\d+)-(-?\d+)$/.exec(key);if(!m)return null;const q=Number(m[1]),r=Number(m[2]),s=parentHexSizeKm();return kmToLonLat([s*Math.sqrt(3)*(q+r/2),s*1.5*r])}
export function hexRing(lon,lat){const[cx,cy]=lonLatToKm([lon,lat]),s=parentHexSizeKm(),p=[];for(let i=0;i<6;i++){const a=(60*i-30)*D;p.push(kmToLonLat([cx+s*Math.cos(a),cy+s*Math.sin(a)]))}p.push(p[0]);return p}
export function buildWorkerHexes(features){const m=new Map();for(const f of features||[]){const c=featureCentroid(f);if(!c)continue;const k=parentKeyForLonLat(c[0],c[1]);if(!m.has(k))m.set(k,[]);m.get(k).push(f)}return[...m].map(([workerHexId,children])=>{const c=parentCenterForKey(workerHexId);return{workerHexId,center:c,geometry:{type:'Polygon',coordinates:[hexRing(c[0],c[1])]},customerHexIds:children.map(f=>f.properties?.hex_id).filter(Boolean)}})}
