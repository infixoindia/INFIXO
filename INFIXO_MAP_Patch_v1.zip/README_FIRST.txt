INFIXO MAP - SAFE PATCH

BASE COMMIT INSPECTED:
6a242d5340f7c1570ef4dbfacff2fb66e05dcfcf

IMPORTANT
- This is an overlay patch, not a full replacement repository.
- Do NOT run any SQL in production until the GIS files are present and the patch has been reviewed.
- Do NOT insert fake workers. The current workers table being empty is expected.
- Public worker/profile routes are not changed by this patch.

GIS FILES REQUIRED
Copy these four existing files into:
public/gis/

1. infixo_hex_grid_indore.geojson
2. imc_boundary_dissolved.geojson
3. wards_indore_cleaned.geojson
4. hex_ward_intersections.csv

The map uses the existing 149 Customer Hex geometries as the immutable source. It does not regenerate them.

CURRENT PATCH
- Adds /admin/map
- Adds an INFIXO MAP link to the existing Admin Workers page
- Adds read-only Admin map API for live worker coordinates
- Adds deterministic Worker Hex generation from the fixed Indore parent-grid configuration
- Adds Customer Hex -> Worker Hex assignment in memory for map display
- Adds worker search by worker_id/name/profession
- Adds Supabase migration tables for future persisted map relationships/demand data

DATABASE
The migration in supabase/migrations/20261001_infixo_map_foundation.sql creates empty map foundation tables only. It does not create workers or insert fake data.

BEFORE RUNNING
1. Put the four GIS files in public/gis/.
2. Run npm run build.
3. Login to /admin and open /admin/map.
4. Confirm Customer Hexes render.
5. Only after code/GIS review, apply the SQL migration.

ROLLBACK
Remove the files added by this patch and do not apply the migration. If the migration has been applied, drop only the three INFIXO map foundation tables created by that migration; do not touch workers/public profile tables.
